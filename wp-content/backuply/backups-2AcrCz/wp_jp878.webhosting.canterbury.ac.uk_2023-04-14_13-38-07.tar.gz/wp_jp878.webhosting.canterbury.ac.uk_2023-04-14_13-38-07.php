<?php exit();?>
{
    "name": "wp_jp878.webhosting.canterbury.ac.uk_2023-04-14_13-38-07",
    "backup_dir": "1",
    "backup_db": "1",
    "email": "admin@jp878.webhosting.canterbury.ac.uk",
    "date_time": "2023-04-14 13:38:pm",
    "btime": 1681479487,
    "auto_backup": false,
    "ext": "tar.gz",
    "size": false,
    "backup_site_url": "https:\/\/jp878.webhosting.canterbury.ac.uk",
    "backup_site_path": "\/home\/rhrrist\/public_html"
}